--青眼の究極竜
function c23995347.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	aux.AddFusionProcMixN(c,true,true,89631139,3)
end
c23995347.listed_names={89631139}
