--ブラック・デーモンズ・ドラゴン
function c11901678.initial_effect(c)
	--fusion material
	c:EnableReviveLimit()
	aux.AddFusionProcMix(c,true,true,70781052,74677422)
end
c11901678.listed_names={74677422}
c11901678.material_setcode={0x3b,0x45}
